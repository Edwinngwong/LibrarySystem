﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A2_NgWongEdwin
{
    class TextBook : Book, IRenewable 
    {
        private int edition;

        public TextBook(string title, string author, int catalogNumber, int edition) : base(title, author, catalogNumber)
        {
            this.edition = edition;
        }

        public override string ToString()
        {
            {
                return base.ToString() + string.Format("{0,40}", "Edition: " + edition);
            }
        }

        public override DateTime FindDueDate()
        {
            return dueDate = (DateTime.Now).AddDays(30);
        }

        public bool Renew()
        {
            if(c != null)
            {
                dueDate = dueDate.AddDays(15);
                return true;
            }
            else 
            {
                return false;
            }
        }
    }
}
