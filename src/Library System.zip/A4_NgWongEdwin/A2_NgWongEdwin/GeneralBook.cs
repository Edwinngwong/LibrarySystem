﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A2_NgWongEdwin
{
    class GeneralBook : Book
    {
        public GeneralBook(string title, string author, int catalogNumber) : base(title, author, catalogNumber) { }

        public override DateTime FindDueDate()
        {
            return dueDate = (DateTime.Now).AddDays(7);
        }
    }
}
