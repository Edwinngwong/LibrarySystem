﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A2_NgWongEdwin
{
    class Customer
    {
        private int id;
        private string name;

        public int Id
        {
            get { return id; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Customer(string name, int id)
        {
            this.id = id; this.name = name;
        }

        public override string ToString()
        {
            return string.Format("{0,-5}{1,-10}", id, name);
        }
    }
}

