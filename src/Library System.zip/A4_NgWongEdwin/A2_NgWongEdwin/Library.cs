﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A2_NgWongEdwin
{
    class Library
    {
        private List<Customer> customerArray = new List<Customer>();
        private List<Book> bookArray = new List<Book>();

        public void AddNewCustomer(string customerName)
        {
            int customerId = 1;
            for (int i = 0; i < customerArray.Count; i++)
            {
                if (customerArray[i] != null) customerId++;
            }
            customerArray.Add(new Customer(customerName, customerId));
        }

        public void AddNewBook(string bookTitle, string bookAuthor)
        {
            int bookCatalogNumber = 101;
            for (int i = 0; i < bookArray.Count; i++)
            {
                if(bookArray[i] != null) bookCatalogNumber++;
            }
            bookArray.Add(new GeneralBook(bookTitle, bookAuthor, bookCatalogNumber));
        }

        public void AddNewBook(string title, string author, int edition)
        {
            int bookCatalogNumber = 101;
            for (int i = 0; i < bookArray.Count; i++)
            {
                if (bookArray[i] != null) bookCatalogNumber++;
            }
            bookArray.Add(new TextBook(title, author, bookCatalogNumber, edition));
        }

        public bool IssueBook(int custId, int bookCatalogNum)
        {
            for (int i = 0; i < bookArray.Count; i++)
            {
                
                {
                    if (bookArray[i].CatalogNumber == bookCatalogNum)
                    {
                        for (int j = 0; j < customerArray.Count; j++)
                        {
                            if (customerArray[j] != null)
                            {
                                if (customerArray[j].Id == custId)
                                {
                                    return (bookArray[i].CheckOut(customerArray[j]));
                                }
                            }
                        }
                    }
                }
            } return false;
        }

        public bool ReturnBook(int bookCatalogNum)
        {
            for (int i = 0; i < bookArray.Count; i++)
            {
                if (bookArray[i] != null)
                {
                    if (bookArray[i].CatalogNumber == bookCatalogNum)
                    {
                        return bookArray[i].CheckIn();
                    } 
                }
            }
            return false;
        }

        public override string ToString()
        {
            string line = "";
            for(int i = 0; i < customerArray.Count; i++)
            {
                line += customerArray[i].ToString() + "\n";
            }

            for(int i = 0; i < bookArray.Count; i++)
            {
                    line += "\n" + bookArray[i].ToString();
            }
            return line + "\n";
        }

        public bool RenewBook(int bookCatalogNum)
        {
            for (int i = 0; i < bookArray.Count; i++)
            {
                if (bookArray[i] != null)
                {
                    if(bookArray[i].CatalogNumber == bookCatalogNum)
                    {
                        if (bookArray[i] is IRenewable)
                        {
                            return ((IRenewable)bookArray[i]).Renew();
                        }
                    }
                }
            } return false;
        }
    }
}
