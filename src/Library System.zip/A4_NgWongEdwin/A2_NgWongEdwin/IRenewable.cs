﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A2_NgWongEdwin
{
    interface IRenewable
    {
        bool Renew();
    }
}
