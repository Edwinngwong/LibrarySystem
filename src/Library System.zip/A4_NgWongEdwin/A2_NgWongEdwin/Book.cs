﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A2_NgWongEdwin
{
    abstract class Book
    {
        private int catalogNumber;
        string title;
        string author;
        protected Customer c;
        protected DateTime dueDate;

        public abstract DateTime FindDueDate();

        public int CatalogNumber
        {
            get { return catalogNumber; }
        }

        public Book(string title, string author, int catalogNo)
        {
            this.title = title; this.author = author; catalogNumber = catalogNo;
        }

        public Book() { }

        public override string ToString()
        {
            if (c != null)
            {
                return string.Format("{0,-5}{1,-20}{2,-20}{3,-54}", catalogNumber, title, author, "Checked-out to Customer " + c.Id + " Due on " + dueDate); 
            }
            else
            {
                return string.Format("{0,-5}{1,-20}{2,-20}{3,-54}", catalogNumber, title, author, "Available");
            }
        }

        public bool CheckOut(Customer c)
        {
            if(this.c != null) 
            { 
                return false;
            }
            else 
            {
                dueDate = FindDueDate();
                this.c = c; 
                return true; 
            }
        }

        public bool CheckIn()
        {
            if(c != null) 
            {
                this.c = null;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
